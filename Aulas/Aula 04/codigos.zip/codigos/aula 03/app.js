const elCarregando = document.getElementById("carregando");
const elErro = document.getElementById("erro");
const corpoTabela = document.getElementById("corpo-tabela");
 
async function consultarEncomendas() {
  elCarregando.style.display = "block";
  elErro.style.display = "none";
 
  try {
    const resposta = await fetch("encomendas.json");
 
    if (!resposta.ok) {
      throw new Error("O servidor respondeu com erro: " + resposta.status);
    }
 
    const encomendas = await resposta.json();
    renderizarTabela(encomendas);
 
  } catch (erro) {
    elErro.textContent = "Não foi possível carregar as encomendas. Tente novamente.";
    elErro.style.display = "block";
    console.error(erro);
 
  } finally {
    elCarregando.style.display = "none";
  }
}

function renderizarTabela(encomendas) {
  corpoTabela.innerHTML = ""; // limpa a tabela antes de preencher de novo
 
  const fragmento = document.createDocumentFragment();
 
  encomendas.forEach(encomenda => {
    const linha = document.createElement("tr");
 
    const tdCodigo = document.createElement("td");
    tdCodigo.textContent = encomenda.codigoRastreio;
 
    const tdCliente = document.createElement("td");
    tdCliente.textContent = encomenda.clienteNome;
 
    const tdStatus = document.createElement("td");
    tdStatus.textContent = encomenda.status;
 
    linha.appendChild(tdCodigo);
    linha.appendChild(tdCliente);
    linha.appendChild(tdStatus);
 
    fragmento.appendChild(linha);
  });
 
  corpoTabela.appendChild(fragmento);
}
 
consultarEncomendas(); // chama a função assim que a página carrega
